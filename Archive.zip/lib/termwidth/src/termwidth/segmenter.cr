# src/termwidth/segmenter.cr
require "./props"
require "./width_profile"
require "./cluster"
require "./layout"

module TermWidth
  struct Segmenter
    getter profile : WidthProfile

    @rules : UInt32

    def initialize(@profile : WidthProfile = WidthProfile::UNICODE)
      @rules = @profile.rules.value
    end

    NARROW = new(WidthProfile::UNICODE)
    WIDE   = new(WidthProfile::UNICODE_WIDE)

    def each(bytes : Bytes, & : Bytes, UInt8 ->) : Nil
      each_span(bytes) do |span, width, ascii|
        if ascii
          ptr = span.to_unsafe
          ro  = span.read_only?
          k   = 0
          while k < span.size
            yield Bytes.new(ptr + k, 1, read_only: ro), 1_u8
            k += 1
          end
        else
          yield span, width
        end
      end
    end

    def each(text : String, & : Bytes, UInt8 ->) : Nil
      each(text.to_slice) { |cluster, width| yield cluster, width }
    end

    def each_span(bytes : Bytes, & : Bytes, UInt8, Bool ->) : Nil
      ptr = bytes.to_unsafe
      ro  = bytes.read_only?
      each_record(bytes) do |start, length, width, run|
        yield Bytes.new(ptr + start, length, read_only: ro), width, run
      end
    end

    def each_span(text : String, & : Bytes, UInt8, Bool ->) : Nil
      each_span(text.to_slice) { |span, width, ascii| yield span, width, ascii }
    end

    def measure(bytes : Bytes) : Int32
      total = 0
      each_record(bytes) { |_, length, width, run| total += run ? length : width.to_i }
      total
    end

    def measure(text : String) : Int32
      measure(text.to_slice)
    end

    def count(bytes : Bytes) : Int32
      total = 0
      each_record(bytes) { |_, length, _, run| total += run ? length : 1 }
      total
    end

    def count(text : String) : Int32
      count(text.to_slice)
    end

    def codepoint_width(cp : UInt32) : UInt8
      prop = Props.lookup(cp)
      return 2_u8 if @profile.wide_ambiguous? && Props.ambiguous?(prop)
      Props.width(prop)
    end

    def cluster_width(bytes : Bytes) : UInt8
      TermWidth.cluster_width(bytes, @rules)
    end

    def cluster_width(text : String) : UInt8
      cluster_width(text.to_slice)
    end

    def locate(bytes : Bytes, *, column : Int32, nearest : Bool = false) : Position
      at  = 0
      col = 0
      each_record(bytes) do |start, length, width, run|
        if run
          if column < col + length
            k = Math.max(column - col, 0)
            return Position.new(start + k, at + k, col + k)
          end
          at  += length
          col += length
        else
          extent = width.to_i
          return Position.new(start, at, col) if column < col + (nearest ? (extent + 1) // 2 : extent)
          at  += 1
          col += extent
        end
      end
      Position.new(bytes.size, at, col)
    end

    def locate(text : String, *, column : Int32, nearest : Bool = false) : Position
      locate(text.to_slice, column: column, nearest: nearest)
    end

    def locate(bytes : Bytes, *, byte : Int32) : Position
      at  = 0
      col = 0
      each_record(bytes) do |start, length, width, run|
        if byte < start + length
          k = run ? Math.max(byte - start, 0) : 0
          return Position.new(start + k, at + k, col + k)
        end
        at  += run ? length : 1
        col += run ? length : width.to_i
      end
      Position.new(bytes.size, at, col)
    end

    def locate(text : String, *, byte : Int32) : Position
      locate(text.to_slice, byte: byte)
    end

    def locate(bytes : Bytes, *, index : Int32) : Position
      at  = 0
      col = 0
      each_record(bytes) do |start, length, width, run|
        span = run ? length : 1
        if index < at + span
          k = Math.max(index - at, 0)
          return Position.new(start + k, at + k, col + k)
        end
        at  += span
        col += run ? length : width.to_i
      end
      Position.new(bytes.size, at, col)
    end

    def locate(text : String, *, index : Int32) : Position
      locate(text.to_slice, index: index)
    end

    def fit_tail(bytes : Bytes, cols : Int32) : Position
      need = measure(bytes) - cols
      return Position.new(0, 0, 0) if need <= 0

      at  = 0
      col = 0
      each_record(bytes) do |start, length, width, run|
        if run
          if need < col + length
            k = Math.max(need - col, 0)
            return Position.new(start + k, at + k, col + k)
          end
          at  += length
          col += length
        else
          return Position.new(start, at, col) if col >= need
          at  += 1
          col += width.to_i
        end
      end
      Position.new(bytes.size, at, col)
    end

    def fit_tail(text : String, cols : Int32) : Position
      fit_tail(text.to_slice, cols)
    end

    def boundary?(bytes : Bytes, byte : Int32) : Bool
      byte >= 0 && byte <= bytes.size && locate(bytes, byte: byte).byte == byte
    end

    def boundary?(text : String, byte : Int32) : Bool
      boundary?(text.to_slice, byte)
    end

    def each_line(bytes : Bytes, cols : Int32, mode : Wrap = Wrap::Word, & : Line ->) : Nil
      breaker = LineBreaker.new(cols, mode.word?)
      each_record(bytes) do |start, length, width, run|
        if run
          k = 0
          while k < length
            at   = start + k
            kind = bytes.unsafe_fetch(at) == 0x20_u8 ? LineBreaker::SPACE : LineBreaker::SOLID
            breaker.feed(at, 1, 1, kind) { |line| yield line }
            k += 1
          end
        else
          breaker.feed(start, length, width.to_i, line_kind(bytes, start, length)) { |line| yield line }
        end
      end
      breaker.finish(bytes.size) { |line| yield line }
    end

    def each_line(text : String, cols : Int32, mode : Wrap = Wrap::Word, & : Line ->) : Nil
      each_line(text.to_slice, cols, mode) { |line| yield line }
    end

    private def line_kind(bytes : Bytes, start : Int32, length : Int32) : Int32
      lead = bytes.unsafe_fetch(start)
      return LineBreaker::HARD if lead == 0x0A_u8 && length == 1
      return LineBreaker::HARD if lead == 0x0D_u8 && length == 2 && bytes.unsafe_fetch(start + 1) == 0x0A_u8

      cp, _ = Utf8.decode(bytes, start)
      prop  = Props.lookup(cp)
      Props.char_class(prop).space? && !Props.no_break?(prop) ? LineBreaker::SPACE : LineBreaker::SOLID
    end

    private def each_record(bytes : Bytes, & : Int32, Int32, UInt8, Bool ->) : Nil
      n = bytes.size
      return if n == 0

      batch = uninitialized StaticArray(Cluster, SEGMENT_BATCH)
      recs  = batch.to_slice
      off   = 0

      while off < n
        count = TermWidth.segment(bytes, off, @rules, recs)
        break if count == 0
        k = 0
        while k < count
          rec = recs.unsafe_fetch(k)
          yield off + rec.start, rec.length, rec.width, (rec.flags & CLUSTER_ASCII_RUN) != 0_u8
          k += 1
        end
        last = recs.unsafe_fetch(count - 1)
        off += last.start + last.length
      end
    end
  end
end
