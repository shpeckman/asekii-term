# src/termwidth/layout.cr
module TermWidth
  record Position, byte : Int32, index : Int32, column : Int32

  record Line, start : Int32, length : Int32, content : Int32, cells : Int32

  enum Wrap
    Word
    Grapheme
  end

  private struct LineBreaker
    SOLID = 0
    SPACE = 1
    HARD  = 2

    @start       = 0
    @used        = 0
    @content     = 0
    @cells       = 0
    @spaced      = false
    @brk         = -1
    @brk_used    = 0
    @brk_content = 0
    @brk_cells   = 0

    def initialize(@cols : Int32, @words : Bool)
    end

    def feed(at : Int32, length : Int32, width : Int32, kind : Int32, & : Line ->) : Nil
      if kind == HARD
        yield Line.new(@start, at + length - @start, at - @start, @used)
        restart(at + length)
        return
      end

      if kind == SPACE && @words
        @used  += width
        @spaced = true if @content > @start
        return
      end

      if @spaced
        @brk         = at
        @brk_used    = @used
        @brk_content = @content
        @brk_cells   = @cells
        @spaced      = false
      end

      if overflows?(width)
        if @brk > @start
          yield Line.new(@start, @brk - @start, @brk_content - @start, @brk_cells)
          shift
        end

        if overflows?(width)
          yield Line.new(@start, at - @start, @content - @start, @cells)
          restart(at)
        end
      end

      @used   += width
      @content = at + length
      @cells   = @used
    end

    def finish(size : Int32, & : Line ->) : Nil
      yield Line.new(@start, size - @start, size - @start, @used)
    end

    private def overflows?(width : Int32) : Bool
      @cols > 0 && @used > 0 && @used + width > @cols && (width > 0 || @used > @cells)
    end

    private def shift : Nil
      if @content > @brk
        @cells -= @brk_used
      else
        @content = @brk
        @cells   = 0
      end
      @used -= @brk_used
      @start = @brk
      @brk   = -1
    end

    private def restart(at : Int32) : Nil
      @start   = at
      @used    = 0
      @content = at
      @cells   = 0
      @spaced  = false
      @brk     = -1
    end
  end
end
