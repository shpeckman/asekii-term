# src/termwidth/version.cr
module TermWidth
  VERSION = {{ `shards version "#{__DIR__}/../.."`.chomp.stringify }}
end
