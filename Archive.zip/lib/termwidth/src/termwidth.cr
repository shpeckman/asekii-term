# src/termwidth.cr
require "./termwidth/version"

require "./termwidth/tables"
require "./termwidth/utf8"
require "./termwidth/grapheme"
require "./termwidth/props"
require "./termwidth/cluster"
require "./termwidth/layout"
require "./termwidth/segmenter"
require "./termwidth/width_profile"

module TermWidth
end
